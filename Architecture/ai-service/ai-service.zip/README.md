# Architecture AI service

Requires Python 3.11 or newer. Run these commands from `Architecture/ai-service` in PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[test]"
.\.venv\Scripts\pytest.exe

$env:PROJECT_CONTEXT_PATH = "../architecture-demo-project/.architecture/project_context.json"
$env:BASE_MODEL = "Qwen/Qwen3-4B-Instruct-2507"
$env:MODEL_MODE = "QLORA"
$env:QLORA_ADAPTER_PATH = "/path/to/qlora_best_adapter"
$env:HOST = "127.0.0.1"
$env:PORT = "8000"
.\.venv\Scripts\python.exe -m app.main
```

`PROJECT_CONTEXT_PATH` defaults to `../architecture-demo-project/.architecture/project_context.json`, relative to the directory used to start the service. `HOST` defaults to `127.0.0.1` and `PORT` to `8000`. The installed `architecture-ai-service` command uses the same configuration.

The service loads schema version `1.0` contexts at startup. A missing or invalid file produces a warning while the service remains available. The loader's `reload()` method replaces the in-memory context only after a successful load.

- `GET /health` returns `{"status": "ok"}`.
- `GET /context/status` returns `{"loaded": false}` or the loaded project name and component/relationship counts.

## Synchronizing project context

`PUT /context/project` accepts the complete existing `project_context.json` document as its request body, without a wrapper. The extension sends the analyzer's architecture metadata, including `schema_version`, `project_name`, `project_root`, `components` and `relationships`. The existing strict Pydantic models validate all component and relationship fields; unexpected fields such as raw source code are rejected. Invalid JSON or structure returns HTTP 422.

```powershell
Invoke-RestMethod -Method Put http://127.0.0.1:8000/context/project `
  -ContentType "application/json" `
  -InFile "../my-spring-project/.architecture/project_context.json"
```

A successful response is `{"updated":true,"project_name":"my-spring-project","components":14,"relationships":23,"rag_invalidated":true}`. Counts come from the validated document. The backend saves it to the existing `PROJECT_CONTEXT_PATH`, creating its parent directory if needed. This path belongs to the backend; `project_root` in the uploaded metadata does not select a storage path.

Saving uses a flushed, synced temporary file in the same directory and atomic replacement. The previous disk file, active context and RAG index remain intact if validation or writing fails. Storage failures return HTTP 503. After saving, the active in-memory context is replaced and the RAG index is invalidated under the retrieval lock. The next retrieval or RAG-enabled `/rules/generate` request builds documents and embeddings from the new context plus the existing base and approved custom rules. Synchronizing does not load or reload Qwen, run embeddings immediately, or change retrieval ranking.

This prototype has **one active project context for one developer/project at a time**. Use one service worker/writer process. Syncing another project replaces the active context for all later requests; the custom rule store is shared and is preserved across project switches. Production deployment should scope project context, rules and indexes per project/session/user and coordinate writes across workers. There is no multi-user/session isolation in this prototype.

## Architecture retrieval

`POST /rag/rebuild` reloads the context and stored rules, creates documents, and rebuilds a CPU FAISS index. `POST /rag/retrieve` accepts a query and an optional positive integer `top_k` (default `5`). A first retrieval builds the index if necessary.

```powershell
Invoke-RestMethod -Method Post http://127.0.0.1:8000/rag/rebuild
Invoke-RestMethod -Method Post http://127.0.0.1:8000/rag/retrieve `
  -ContentType "application/json" `
  -Body '{"query":"Only PaymentService may depend on PaymentGateway.","top_k":5}'
```

The embedding model defaults to `BAAI/bge-small-en-v1.5`. It loads only when a RAG build or retrieval needs embeddings; startup and health checks do not import Sentence Transformers or download weights. Sentence Transformers brings PyTorch and Transformers as transitive embedding dependencies. These are not direct dependencies or Qwen inference integrations.

The index, its ordered documents, and their metadata stay together in memory. Restarting the service requires another build. Context synchronization and rule approval invalidate the index automatically. There is no file watcher: use `/rag/rebuild` after editing context or rule files directly. If rebuilding fails, the previous index remains intact; an index for a different loaded context cannot be queried until rebuilt.

Additional configuration:

| Environment variable | Default |
| --- | --- |
| `BASE_RULES_PATH` | `Architecture/rules/base-rules.json`, located relative to the source checkout |
| `CUSTOM_RULES_PATH` | `Architecture/rules/custom-rules.json`, located relative to the source checkout |
| `EMBEDDING_MODEL` | `BAAI/bge-small-en-v1.5` |
| `EMBEDDING_CACHE_DIR` | Sentence Transformers' default cache |

Custom rules use `{"rules": [...]}` with the same stored rule envelope as base rules. The file starts empty. Stored `VALID` entries are included; entries marked `is_exception: true` or `rule_type: EXCEPTION` become exception documents. The approval endpoints below validate and persist approved rules to this collection.

All returned scores are cosine-style similarities from normalized embeddings. The retriever follows the [BGE model card](https://huggingface.co/BAAI/bge-small-en-v1.5) by adding its retrieval instruction to queries only. The same retriever can be used by later base-model and adapter-backed inference code.

Results are the global top-k by vector similarity; document types do not have reserved slots. Related dependency, call, and import documents can outrank component descriptions. Increase `top_k` when a query needs broader context across document types.

Normal tests use a deterministic embedding substitute with real FAISS and make no model-download requests. Real BGE checks are run separately during integration validation.

## Qwen / QLoRA rule generation + RAG

`POST /rules/generate` retrieves architecture documents, builds the existing chat prompt from the shared `Architecture/schemas/rule.schema.json`, and runs `Qwen/Qwen3-4B-Instruct-2507` with the configured trained adapter. **QLORA is the default and intended PP1 mode.** There is no automatic fallback to base-model inference. The first RAG-enabled request builds the index automatically when a project context is loaded. Missing context returns HTTP 409 before model inference. Set `use_rag` to `false` to generate without retrieval or a loaded project context.

```powershell
Invoke-RestMethod -Method Post http://127.0.0.1:8000/rules/generate `
  -ContentType "application/json" `
  -Body '{"requirement":"Only PaymentService may depend on PaymentGateway.","use_rag":true}'
Invoke-RestMethod http://127.0.0.1:8000/model/status
```

| Environment variable | Default |
| --- | --- |
| `BASE_MODEL` | `Qwen/Qwen3-4B-Instruct-2507` |
| `MODEL_MODE` | `QLORA`; use `BASE` only for intentional base-model inference |
| `QLORA_ADAPTER_PATH` | No default; required for QLORA generation |
| `MODEL_ID` | Legacy alias for `BASE_MODEL`; if both are set, they must agree |
| `MODEL_MAX_NEW_TOKENS` | `180` |
| `RAG_TOP_K` | `8` |

The tokenizer, quantized base model and adapter load only on the first generation request and are reused. `/health` and `/model/status` do not import GPU/model libraries or load weights. Generation requests are serialized to avoid overlapping GPU allocations. Successful context sync, rule approval and RAG invalidation do not reload the model.

### PP1 deployment / Kaggle runtime example

Install the declared service dependencies, including PEFT, into a CUDA-capable environment. Mount/copy the selected trained adapter, then pass its actual directory through the environment. These Linux/Kaggle-style commands are an example; the paths depend on the running notebook/session and are never hardcoded in application code:

```bash
cd Architecture/ai-service
python -m pip install -e ".[test]"
export BASE_MODEL="Qwen/Qwen3-4B-Instruct-2507"
export MODEL_MODE="QLORA"
export QLORA_ADAPTER_PATH="/path/to/qlora_best_adapter"
export PROJECT_CONTEXT_PATH="/path/to/writable/project_context.json"
export HOST="0.0.0.0"
export PORT="8000"
python -m app.main
```

The adapter directory must contain `adapter_config.json` and `adapter_model.safetensors`. Its configuration must identify the same base model, use `peft_type: LORA`, and target causal language modeling. Files/configuration are checked before base weights are downloaded. The existing NF4/double-quantized FP16 base is wrapped with `PeftModel.from_pretrained(..., is_trainable=False)` using local adapter files; it is not merged or trained. Missing or incompatible artifacts and PEFT/tokenizer loading failures return a clear HTTP 503 and never publish a base-only model as a loaded QLoRA model. Startup/health remain available because model initialization is lazy.

If the saved adapter includes tokenizer assets, the tokenizer/chat template is loaded from that directory with `local_files_only=True`. An incomplete bundled tokenizer fails instead of being silently replaced. When no tokenizer assets were saved, the base Qwen tokenizer/chat template is used. Export the training tokenizer together with the adapter if training changed it. Prompts, greedy decoding, the token limit and RAG ranking are unchanged. No adapter files or research results are generated by this deployment change.

After the first successful generation, `GET /model/status` reports:

```json
{
  "loaded": true,
  "model_id": "Qwen/Qwen3-4B-Instruct-2507",
  "base_model": "Qwen/Qwen3-4B-Instruct-2507",
  "model_mode": "QLORA",
  "adapter_loaded": true,
  "device": "cuda:0"
}
```

Before loading, `loaded` and `adapter_loaded` are false and `device` is null; `model_mode` still shows the configured mode. Status does not expose the adapter's filesystem path. To run base-only mode explicitly, set `MODEL_MODE=BASE` and unset `QLORA_ADAPTER_PATH`; configuring both is rejected. Base mode is logged clearly. Restart the service after changing model/adapter environment variables.

QLoRA is used only for rule generation. **Deterministic conformance checking does not depend on Qwen/QLoRA** and remains available even when model initialization fails. Authentication, remote routing and tunnel setup remain deployment responsibilities. The loader follows the [PEFT model loading API](https://huggingface.co/docs/peft/package_reference/peft_model) and [PEFT quantization guidance](https://huggingface.co/docs/peft/developer_guides/quantization).

This configuration uses bitsandbytes NF4 with double quantization, FP16 compute and model dtype, and `device_map="auto"`. Install a CUDA-enabled PyTorch build suitable for your NVIDIA GPU before inference. A CPU-only installation returns a readable HTTP 503 before downloading Qwen weights. Loading and generation failures also return HTTP 503 while health checks remain available. There is no automatic fallback to a different model or precision. Model downloads use the standard Hugging Face cache configuration, including `HF_HOME`.

The response preserves the exact `generated_text`. Whitespace and a complete outer JSON/code fence are removed only for parsing. `rule` contains the parsed JSON value; on invalid JSON it is null and `json_valid` is false. `json_valid` reports JSON syntax. A separate deterministic validator reports `schema_valid` and field-level `validation_errors` after parsing. The `retrieved_context` array contains the actual documents and similarity scores used for the prompt. Generation uses greedy decoding; the token limit may leave an incomplete JSON result, which is returned without repair.

## Deterministic rule validation

`app/rule_validator.py` uses `jsonschema` with the shared `Architecture/schemas/rule.schema.json`. Required fields, enum values, types, scope and additional-property restrictions come from that file. The validator also requires `rule: null` for `AMBIGUOUS` and `UNSUPPORTED` results, as requested for generated rules; the unchanged shared schema is more permissive about those statuses. Whitespace-only source and target names are rejected.

The validator returns `{"valid":true,"errors":[]}` or field errors such as `{"valid":false,"errors":[{"path":"rule.action","message":"..."}]}`. Errors are sorted and duplicates are removed. No names or semantic values are changed, and no normalization is applied. Parsing still removes outer fences and whitespace from the text used for JSON decoding without modifying `generated_text`.

`POST /rules/generate` returns `schema_valid: true` only when JSON parses and passes deterministic validation. Parseable but invalid rules remain in `rule`, with `json_valid: true`, `schema_valid: false` and validation errors. Malformed JSON produces both flags as false, `rule: null` and a root (`$`) error. Rule validation does not check project entities, conflicts or architecture conformance, and does not persist rules.

The implementation follows the [Qwen model card](https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507) for chat formatting and the [Transformers bitsandbytes documentation](https://huggingface.co/docs/transformers/quantization/bitsandbytes) for quantized loading, with FP16 explicitly selected for this project.

Run the opt-in integration test separately on a machine with sufficient GPU memory:

```powershell
$env:PROJECT_CONTEXT_PATH = "../architecture-demo-project/.architecture/project_context.json"
$env:RUN_QWEN_INTEGRATION = "1"
$env:MODEL_MODE = "BASE"
Remove-Item Env:QLORA_ADAPTER_PATH -ErrorAction SilentlyContinue
.\.venv\Scripts\pytest.exe -m integration -s
Remove-Item Env:RUN_QWEN_INTEGRATION
```

This existing opt-in test explicitly uses BASE mode to preserve the base-model research experiment. It runs the three research requirements against real embeddings and FAISS, then Qwen if CUDA is available. It saves the retrieved documents, untouched model output, parsed JSON, syntax validity and load/generation timings to the ignored `.tools/base-qwen-rag-results.json`. Without CUDA it still saves real retrieval results and records Qwen generation as skipped; output and timing fields remain null. Normal `pytest` runs skip this test and use mocked base/adapter loading in unit tests. They do not validate real adapter weights or require a GPU. Restore the QLORA environment after running the base experiment.

## Custom rule approval and conflicts

`POST /rules/check-conflicts` and `POST /rules/approve` accept the parsed rule envelope from the generation response's `rule` field. Send that entire envelope, including `status`, its nested `rule`, and `reason_code`; do not send the full HTTP generation response. Both endpoints require a schema-valid `VALID` envelope and validate it again independently of any caller-supplied validation flags.

```json
{
  "rule": {
    "status": "VALID",
    "rule": {
      "rule_type": "COMPONENT_ACCESS",
      "source": {"entity_type": "COMPONENT", "name": "PaymentService"},
      "relationship": "DEPENDS_ON",
      "target": {"entity_type": "COMPONENT", "name": "PaymentGateway"},
      "action": "ONLY",
      "scope": {"type": "PROJECT", "value": null},
      "is_exception": false
    },
    "reason_code": null
  }
}
```

The check endpoint returns `has_conflict`, `duplicate`, and a `conflicts` list containing existing rule IDs and readable reasons. The backend compares exact rule types, entity types and names, relationships, targets and scopes. There is no name normalization, alias inference, layer/package expansion, or LLM involvement.

`ONLY` means its source is the only allowed source for that relationship to the target. A different source with `ALLOW` or `ONLY` conflicts, regardless of which rule was approved first. `ALLOW` and `DENY` conflict for the same source, relationship, target and scope. Other action combinations are not evaluated in this commit. Duplicate detection compares the complete rule body, including scope and `is_exception`, while ignoring envelope IDs. Exception entries retain their flags and can be recognized as exact duplicates; precedence and other conflicts involving exception entries are deferred.

Approval checks the current file again within the write transaction. Conflicts return HTTP 409 with conflict details and leave storage unchanged. Add the top-level boolean `"confirm_conflicts": true` to the approval request to explicitly override. The default is false; it cannot bypass schema validation. No model is loaded by checking or approving rules.

Successful approval returns, for example, `{"approved":true,"rule_id":"CUSTOM_001","conflicts_confirmed":false,"duplicate":false}`. IDs are generated from the highest existing `CUSTOM_` number; caller-supplied IDs are not used for new entries. Approving an exact duplicate returns the existing ID with `duplicate: true`, without writing or requesting confirmation again, including when previously confirmed rules now contradict each other.

The default persistence path is `Architecture/rules/custom-rules.json`; `CUSTOM_RULES_PATH` overrides it. A missing file is treated as an empty store. Existing entries must validate, have unique non-empty IDs, and be `VALID`. Malformed or invalid storage returns HTTP 503 and is not overwritten. Entries are written in deterministic order through a flushed, synced temporary file in the same directory, followed by atomic replacement. A failed write leaves the previous file intact. Thread locks shared by path serialize approvals within one service process; use one writer process for this JSON store. Independent worker processes or external edits require separate coordination.

After a new rule is persisted through the service, its RAG index is invalidated. The next retrieval rebuilds using the same document builder and includes approved custom rules. This keeps approval independent of embedding/model availability. Direct external edits still require `/rag/rebuild`; there is no file watcher. Runtime conformance and exception precedence are handled separately by the endpoint below; the approval conflict detector keeps its existing semantics.

## Deterministic architecture conformance

**LLM-generated rules are validated and approved first; conformance is evaluated deterministically.** `POST /conformance/check` evaluates the active validated project context against the current `BASE_RULES_PATH` and the approved `CUSTOM_RULES_PATH` store. It needs no request body, model, embeddings or RAG index. The engine does not import inference or retrieval modules, and it neither loads Qwen nor changes the RAG index.

```powershell
Invoke-RestMethod -Method Post http://127.0.0.1:8000/conformance/check
```

The response contains `project_name`, `conformant`, `violations`, `summary` (`total`, `base_rule_violations`, `custom_rule_violations`) and `rule_metadata`. Each violation follows the unchanged `Architecture/schemas/violation.schema.json`. Use `rule_metadata[violation.rule_id]` to get its `rule_type` and `rule_source` (`BASE` or `CUSTOM`); those fields cannot be inserted into a violation because its schema forbids additional properties.

Violations use qualified source names, deterministic messages, severity `ERROR` and project-relative source paths. A relationship's source location is used when available; otherwise the source declaration's location is used. Placement and missing-dependency findings use the declaration. IDs are stable hashes of the project name, rule source/ID and source evidence. Identical evidence is deduplicated; distinct source occurrences remain separate findings. Findings are sorted by rule, source/target, relationship and location. Multiple applicable restrictions may report the same evidence under different rule IDs.

### Supported semantics

- `DENY`: report every matching analyzed relationship. Layer selectors use `spring_type`, never class-name suffixes. `COMPONENT` selects an entity regardless of its declaration kind; `CLASS` and `INTERFACE` retain their declaration-type restrictions.
- `ALLOW`: grant permission without requiring an edge or creating a project-wide allow-list. A project can conform when an allowed edge is absent.
- `ONLY`: its source is the only allowed incoming source for the selected relationship and target. `PaymentService ONLY DEPENDS_ON PaymentGateway` permits PaymentService's edge and reports ReportingService's edge. It does not limit PaymentService's other dependencies or require anyone to access PaymentGateway. A layer/package source permits the matching source group.
- `REQUIRE`: every existing matching source must have at least one relationship to a matching target. Group targets are existential, not all-to-all. A missing target produces a declaration-level violation for an existing source. No source entities are invented: a missing source selector has no applicable source, so this is not an entity-existence assertion. For `ONLY`, a missing allowed source still excludes actual competing sources.
- `LOCATED_IN`: use each component's actual `package` as a placement relationship. Short package selectors such as `controller` match a complete dot-separated segment anywhere (`com.example.order.controller` matches; `controllers` does not). Qualified selectors match that exact package and its subpackages, using dot boundaries. Package selectors on ordinary dependency rules select entities in those packages.
- Graph evaluation supports `DEPENDS_ON`, `CALLS`, `IMPORTS`, `EXTENDS` and `IMPLEMENTS` independently. An import or call is not silently treated as a dependency. No transitive relationships are inferred.

Named selectors accept exact qualified names or unique simple names. An ambiguous simple name fails with a readable service error requiring qualification, rather than matching several entities. External qualified targets can match an exact `COMPONENT` selector when an analyzed edge references them; no external class/interface, Spring-layer or package metadata is guessed. Edges without an analyzed source are not reported because they lack a reliable source file/location.

### Permissions, exceptions and precedence

1. Rules marked `is_exception: true` or `rule_type: EXCEPTION` retain their actual action. A matching specific `ALLOW` exception can suppress a normal restriction at equal named-entity specificity or a broader restriction. Flagging a rule does not turn a `DENY` or `REQUIRE` into permission.
2. A custom `ALLOW`, or the allowed source of a custom `ONLY`, can override a normal broader restriction when its source/target selectors are no broader and at least one is more specific. Named entities are narrower than a matching layer/package category; qualified package subtrees can narrow a package category. Package and Spring-layer categories are incomparable, since they can overlap without containing one another.
3. Otherwise `DENY` and `ONLY` remain enforced. Equal-specificity ordinary `ALLOW` does not cancel a restriction. In particular, an ordinary ReportingService permission does not cancel an equally specific PaymentService-only rule; a matching approved exception can. Ordinary permissions never override exception restrictions. If exceptions conflict at equal specificity, restrictions remain enforced; a more specific matching exception permission can override a broader one.

Permission matching always includes the actual relationship, source and target. For `ONLY`, specificity is compared to the allowed-source selector even though the offending source is excluded from it. An exception for one controller, target or relationship never opens unrelated access. Results do not depend on storage order or a last-rule-wins policy.

A specific placement permission can explicitly allow an alternative actual package and suppress a broader placement requirement. Dependency `ALLOW`, including an exception permission, does not waive a missing required dependency: permission and existence remain different conditions. No additional missing-dependency waiver syntax is inferred from the existing ontology.

### Errors and current limits

Missing active context returns HTTP 409 with instructions to analyze and sync first. The existing custom store is the approval boundary: pending, rejected, `AMBIGUOUS` and `UNSUPPORTED` generations are not runtime rules. Malformed/invalid rule storage, duplicate rule IDs, ambiguous names or unsupported semantic combinations return HTTP 503 rather than a false conformant result. Duplicate canonical project entities return HTTP 409. `LOCATED_IN` requires a `PACKAGE` target, and `PACKAGE_PLACEMENT` rules must use `LOCATED_IN`.

Checks use the in-memory context snapshot captured when the request starts and load stored rules on each check. They do not reparse Java or reload arbitrary context files. Analyze and sync again after source changes. The existing one-project, one-writer-process limitation still applies. Evaluation covers only relationships and source evidence provided by the analyzer, not reflection, runtime wiring or unresolved external behavior. Conflicting mandatory requirements remain violations; conformance does not revise approved rules or run conflict detection again.

`tests/test_conformance_engine.py` covers rule semantics, resolution, precedence, stable output, shared-schema compatibility and import isolation. `tests/test_conformance_api.py` covers active-context synchronization, approved-rule inclusion, exceptions, counts and unavailable inference/embedding services. These tests require no model downloads. VS Code diagnostics and violation UI are deferred to Commit 15; the extension is unchanged by this commit.
