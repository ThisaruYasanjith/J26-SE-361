"""Architecture context service."""
